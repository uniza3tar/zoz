import MenuFive from "./Menu/MenuFive";

export default function HeaderFive(props) {
  return <MenuFive {...props} />;
}
