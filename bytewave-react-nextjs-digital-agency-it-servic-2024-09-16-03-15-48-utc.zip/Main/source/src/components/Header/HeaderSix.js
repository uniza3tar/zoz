import MenuSix from "./Menu/MenuSix";

export default function HeaderSix(props) {
  return <MenuSix classname={'-style-2 -style-6'} {...props} />;
}
