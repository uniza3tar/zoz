import MenuSeven from "./Menu/MenuSeven";

export default function HeaderSeven(props) {
  return <MenuSeven {...props} />;
}
