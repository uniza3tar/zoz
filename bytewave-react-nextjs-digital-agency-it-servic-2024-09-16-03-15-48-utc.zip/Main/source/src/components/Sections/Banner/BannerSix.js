import React from 'react'
import Image from 'next/image'
import Marquee from 'react-fast-marquee'

const BannerSix = () => {
    return (
        <section className={`banner-block lg:py-20 sm:py-14 py-10`}>
            <Marquee>
                <h2 className={`heading1 pb-2 capitalize px-[30px] opacity-10`}>Boost Your Rankings - Act Now!</h2>
                <h2 className={`heading1 pb-2 capitalize px-[30px] opacity-10`}>Boost Your Rankings - Act Now!</h2>
                <h2 className={`heading1 pb-2 capitalize px-[30px] opacity-10`}>Boost Your Rankings - Act Now!</h2>
                <h2 className={`heading1 pb-2 capitalize px-[30px] opacity-10`}>Boost Your Rankings - Act Now!</h2>
                <h2 className={`heading1 pb-2 capitalize px-[30px] opacity-10`}>Boost Your Rankings - Act Now!</h2>
                <h2 className={`heading1 pb-2 capitalize px-[30px] opacity-10`}>Boost Your Rankings - Act Now!</h2>
                <h2 className={`heading1 pb-2 capitalize px-[30px] opacity-10`}>Boost Your Rankings - Act Now!</h2>
                <h2 className={`heading1 pb-2 capitalize px-[30px] opacity-10`}>Boost Your Rankings - Act Now!</h2>
            </Marquee>
        </section>
    )
}

export default BannerSix